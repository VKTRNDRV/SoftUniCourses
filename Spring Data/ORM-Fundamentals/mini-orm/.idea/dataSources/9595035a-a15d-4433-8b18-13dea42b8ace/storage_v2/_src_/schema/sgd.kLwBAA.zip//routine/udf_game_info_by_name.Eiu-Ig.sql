create
    definer = root@localhost function udf_game_info_by_name(game_name varchar(20)) returns varchar(255) deterministic
begin
	declare team_id int;
    declare office_id int;
    declare address_id int;
	declare team_name varchar(40);
    declare address_text varchar(50);
    declare output varchar(255);
    
    select games.team_id into team_id
    from games
    where games.`name` = game_name;
    
    select teams.`name` into team_name
    from teams
    where teams.id = team_id;
    
    select teams.office_id into office_id
    from teams
    where teams.id = team_id;
    
    select offices.address_id into address_id
    from offices
    where offices.id = office_id;
    
    select addresses.`name` into address_text
    from addresses
    where addresses.id = address_id;
    
    select concat('The ', game_name, ' is developed by a ', team_name, ' in an office with an address ', address_text) into output;
    return output;
end;

