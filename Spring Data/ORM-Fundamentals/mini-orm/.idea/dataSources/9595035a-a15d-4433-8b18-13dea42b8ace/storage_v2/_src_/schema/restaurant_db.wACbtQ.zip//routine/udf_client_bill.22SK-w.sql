create
    definer = root@localhost function udf_client_bill(full_name varchar(50)) returns decimal(10, 2) deterministic
begin
	declare target_customer_id int;
    declare total_price decimal(10, 2);
    
    select id into target_customer_id
    from clients
    where concat_ws(' ', first_name, last_name) = full_name;
    
    select sum(p.price) into total_price
    from orders_clients oc
		join orders o on oc.order_id = o.id
        join orders_products op on o.id = op.order_id
        join products p on op.product_id = p.id
	where oc.client_id = target_customer_id;
    return total_price;
end;

