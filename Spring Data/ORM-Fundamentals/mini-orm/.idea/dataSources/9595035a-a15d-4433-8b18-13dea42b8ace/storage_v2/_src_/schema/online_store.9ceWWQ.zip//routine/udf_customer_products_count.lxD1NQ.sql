create
    definer = root@localhost function udf_customer_products_count(name varchar(30)) returns int deterministic
begin
	declare target_customer_id int;
	declare product_count int;
    
    select id into target_customer_id
    from customers
    where first_name = `name`;
    
    select count(op.product_id) into product_count
    from orders o
		join orders_products op on o.id = op.order_id
	where o.customer_id = target_customer_id;
    
    return product_count;
end;

