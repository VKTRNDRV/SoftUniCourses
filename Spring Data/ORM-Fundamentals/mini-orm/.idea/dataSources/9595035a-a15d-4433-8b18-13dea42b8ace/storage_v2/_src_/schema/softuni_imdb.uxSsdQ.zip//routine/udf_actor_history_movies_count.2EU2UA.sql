create
    definer = root@localhost function udf_actor_history_movies_count(full_name varchar(50)) returns int deterministic
begin
	declare target_actor_id int;
    declare history_movies_count int;
    
    select id into target_actor_id
    from actors
    where concat_ws(' ', first_name, last_name) = full_name;
    
    select count(m.id) into history_movies_count
    from movies_actors ma
		join movies m on ma.movie_id = m.id
        join genres_movies gm on m.id = gm.movie_id
	where actor_id = target_actor_id
		and gm.genre_id = 12;
    
    return history_movies_count;
end;

