create
    definer = root@localhost function udf_courses_by_client(phone_num varchar(20)) returns int deterministic
begin
	declare target_client_id int;
    declare count_of_courses int;
    select id into target_client_id
    from clients
    where phone_number = phone_num
    limit 1;
    
    select count(id) into count_of_courses
    from courses
    where client_id = target_client_id;
    
    if count_of_courses is null
		then return 0;
	else
		return count_of_courses;
	end if;
end;

