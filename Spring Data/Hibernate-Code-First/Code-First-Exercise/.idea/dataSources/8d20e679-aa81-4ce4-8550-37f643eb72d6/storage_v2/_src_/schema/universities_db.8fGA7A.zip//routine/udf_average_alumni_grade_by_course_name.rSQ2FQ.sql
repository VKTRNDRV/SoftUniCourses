create
    definer = root@localhost function udf_average_alumni_grade_by_course_name(course_name varchar(60)) returns decimal(19, 2)
    deterministic
begin
	declare target_course_id int;
    declare avg_grade decimal(19, 2);
    
    select id into target_course_id
    from courses
    where `name` = course_name;
    
    select avg(sc.grade) into avg_grade
    from students s
		join students_courses sc on s.id = sc.student_id
	where s.is_graduated = 1
		and sc.course_id = target_course_id;
        
	return avg_grade;
end;

